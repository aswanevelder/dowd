dotnet publish -r linux-x64 --self-contained true
cd /Users/antonswanevelder/_trublo/dowd/bin/Debug/net5.0/linux-x64/publish
zip -r archive.zip *.*